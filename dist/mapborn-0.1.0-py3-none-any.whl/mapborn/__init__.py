# mapborn/__init__.py
from .plot import Map
__version__ = "0.1.0"